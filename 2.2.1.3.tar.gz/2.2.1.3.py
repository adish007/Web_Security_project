import hashlib

result = hashlib.md5(b"'='.")
print(result.digest())

